/** metode require (node standard) */
//jQuery
window.$ = window.jQuery = require('jquery');
//overlayScrollbars
require('overlayscrollbars');
//popper.js
require('popper.js');
//Bootstrap 4
require('bootstrap');
//AdminLTE
require('../assets/js/adminlte');
