#!/bin/bash
vendor/bin/phpunit --filter it_returns_list_of_active_projects
