<?php

namespace App\Repositories\Contracts;

use App\Repositories\Data\DataRepositoryInterface;

interface ContractStatusRepositoryInterface extends DataRepositoryInterface
{
    // Add specific methods if needed
}
