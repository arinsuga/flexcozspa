<?php

namespace App\Repositories\Contracts;

use App\Repositories\Data\DataRepositoryInterface;

interface ProjectStatusRepositoryInterface extends DataRepositoryInterface
{
    // Add specific methods if needed
}
