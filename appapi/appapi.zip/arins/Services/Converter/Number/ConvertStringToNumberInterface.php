<?php
namespace Arins\Services\Converter\Number;

interface ConvertStringToNumberInterface
{
    /**
     * ======================================================
     * 1. Date Standard 3 Methods
     * ====================================================== */
    public function strToNumber($data);

}
