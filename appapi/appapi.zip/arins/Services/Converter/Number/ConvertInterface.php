<?php
namespace Arins\Services\Converter\Number;

interface ConvertInterface extends ConvertStringToNumberInterface
{
    /**
     * ======================================================
     * 1. Inherit from ConvertStringToNumberInterface
     * ====================================================== */

}
