<?php
namespace Arins\Services\Converter\Date;

interface ConvertInterface extends ConvertStringToDateInterface, ConvertMillisToDateInterface, ConvertDateToDateInterface
{
    /**
     * ======================================================
     * 1. Inherit from ConvertStringToDateInterface
     * ====================================================== */

}
