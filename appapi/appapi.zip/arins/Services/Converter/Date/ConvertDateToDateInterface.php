<?php
namespace Arins\Services\Converter\Date;

interface ConvertDateToDateInterface
{
    /**
     * ======================================================
     * 1. Timezone 1 Methods
     * ====================================================== */
    public function DatetimeByTimezone($data, $timezone);
}
